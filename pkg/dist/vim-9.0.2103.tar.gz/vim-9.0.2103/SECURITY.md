# Security Policy

## Reporting a vulnerability

If you want to report a security issue, please privately disclose the issue to the vim-security mailing list
vim-security@googlegroups.com

This is a private list, read only by the maintainers, but anybody can post, after moderation.

**Please don't publicly disclose the issue until it has been addressed by us.**

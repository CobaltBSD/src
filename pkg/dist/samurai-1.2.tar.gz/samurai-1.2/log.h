struct node;

void loginit(const char *);
void logclose(void);
void logrecord(struct node *);

/*
 * Copyright (C) 2023 NRK.
 *
 * This file is part of sxot.
 *
 * sxot is free software: you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version.
 *
 * sxot is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License
 * along with sxot. If not, see <https://www.gnu.org/licenses/>.
 */

#define _POSIX_C_SOURCE 200112L  // NOLINT

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <limits.h>

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/extensions/Xfixes.h>

typedef uint8_t     u8;
typedef uint32_t    u32;
typedef uint64_t    u64;
typedef ptrdiff_t   Size;
typedef struct { u8 *s; Size len; } Str;

#define NOP()           ((void)0)
#define SIZEOF(...)     ((Size)sizeof(__VA_ARGS__))
#define S(X)            ((Str){ .s = (u8 *)(X), .len = SIZEOF(X) - 1})
#define fatal(...)      fatal_core( \
	(Str []){ __VA_ARGS__ }, \
	SIZEOF((Str []){ __VA_ARGS__ }) / SIZEOF(Str) \
)

#ifdef __GNUC__
	// when debugging, use gcc/clang and compile with
	// `-fsanitize=undefined -fsanitize-undefined-trap-on-error`
	// it'll trap if an unreachable code-path is ever reached.
	#define ASSERT(X)  ((X) ? (void)0 : __builtin_unreachable())
#else
	#define ASSERT(X)  ((void)0)
#endif
#ifndef VERSION
	#define VERSION "v0.1.0"
#endif

_Noreturn
static void
fatal_core(Str *sv, Size n)
{
	for (Size i = 0; i < n; ++i) {
		ASSERT(sv[i].len > 0);
		fwrite(sv[i].s, 1, sv[i].len, stderr);
	}
	exit(1);
}

static Str
str_from_cstr(char *s)
{
	Str ret = { .s = (u8 *)s };
	for (NOP(); s != NULL && s[ret.len] != '\0'; ++ret.len) {}
	return ret;
}

static bool
str_eq(Str a, Str b)
{
	Size n = -1;
	ASSERT(a.len >= 0 && b.len >= 0);
	if (a.len == b.len) {
		for (n = 0; n < a.len && a.s[n] == b.s[n]; ++n) {}
	}
	return n == a.len;
}

static Str
str_tok(Str *s, u8 ch)
{
	Str ret = { .s = s->s };
	ASSERT(!(s->len < 0));
	for (NOP(); ret.len < s->len && ret.s[ret.len] != ch; ++ret.len) {}
	s->s   += ret.len + (ret.len < s->len);
	s->len -= ret.len + (ret.len < s->len);
	return ret;
}

static bool
str_to_int(Str s, int *out)
{
	u64 n = 0;
	ASSERT(!(s.len < 0));
	for (Size i = 0; i < s.len; ++i) {
		u8 ch = s.s[i];
		n = (n * 10) + (ch - '0');
		if (n > INT_MAX || !(ch >= '0' && ch <= '9')) {
			return false;
		}
	}
	*out = n;
	return s.len > 0;
}

static u8 *
int_to_str(u8 p[static 32], int n)
{
	ASSERT(n >= 0);
	u8 *q = p + 32, *end = q;
	do {
		*--q = (n % 10) + '0';
	} while (n /= 10);
	while (q < end) {
		*p++ = *q++;
	}
	return p;
}

static void
write_ppm(u8 *data, int width, int height, bool msb_first)
{
	{
		u8 hdr[128] = "P6\n", *p = hdr + 3;
		p = int_to_str(p, width);  *p++ = ' ';
		p = int_to_str(p, height); *p++ = '\n';
		*p++ = '2'; *p++ = '5'; *p++ = '5'; *p++ = '\n';
		ASSERT(p < (hdr + SIZEOF(hdr)));
		fwrite(hdr, 1, p - hdr, stdout);
	}

	u8 *w = data;
	u8 *end = data + ((Size)width * height * 4);
	for (u8 *p = data; p < end; p += 4) {
		int R, G, B;
		if (msb_first) {
			R = p[1]; G = p[2]; B = p[3];
		} else {
			R = p[2]; G = p[1]; B = p[0];
		}
		*w++ = R; *w++ = G; *w++ = B;
	}
	ASSERT(w < end);
	fwrite(data, 1, w - data, stdout);
	fflush(stdout);
	if (ferror(stdout)) {
		fatal(S("error writing to stdout\n"));
	}
}

static void
blend_cursor(XImage *im, XFixesCursorImage *cur)
{
	int yend = (cur->y + cur->height) < im->height ?
	           (cur->y + cur->height) : im->height;
	int xend = (cur->x + cur->width) < im->width ?
	           (cur->x + cur->width) : im->width;
	int R, G, B;
	if (im->byte_order == MSBFirst) {
		R = 1; G = 2; B = 3;
	} else {
		R = 2; G = 1; B = 0;
	}
	for (int y = cur->y, yc = 0; y < yend; ++y, ++yc) {
		for (int x = cur->x, xc = 0; x < xend; ++x, ++xc) {
			Size off = ((Size)y * im->width) + x;
			u8 *p = (u8 *)im->data + (off * 4);
			u32 c = cur->pixels[(yc * cur->width) + xc];
			u32 a = (c >> 24) & 0xFF;
			if (a == 0) {
				continue;
			}
			p[R] = ((((c >> 16) & 0xFF) * a) + (p[R] * (0xFF - a))) / 0xFF;
			p[G] = ((((c >>  8) & 0xFF) * a) + (p[G] * (0xFF - a))) / 0xFF;
			p[B] = ((((c >>  0) & 0xFF) * a) + (p[B] * (0xFF - a))) / 0xFF;
		}
	}
}

static bool
parse_geom(int v[static 4], Str s)
{
	for (int *end = v + 4; v < end; ++v) {
		if (!str_to_int(str_tok(&s, ','), v) || *v < 0) {
			return false;
		}
	}
	return s.len == 0;
}

extern int
main(int argc, char *argv[])
{
	Str usage = S(
		"usage: sxot [options]\n"
		"Options:\n"
		"  -g, --geom <x,y,w,h>   Capture the specified rectangle\n"
		"  -c, --curosr           Capture the cursor also\n"
	);
	Str version = S(
		"sxot " VERSION "\n"
		"Copyright (C) 2023 NRK.\n"
		"License: GPLv3+ <https://gnu.org/licenses/gpl.html>\n"
		"Upstream: <https://codeberg.org/NRK/sxot>\n"
	);

	struct {
		union {
			int v[4];
			struct { int x, y, w, h; };
		};
		bool capture_cursor;
	} opt = { .x = -1 };
	struct { Display *dpy; Window root; } x11;


	if ((x11.dpy = XOpenDisplay(NULL)) == NULL) {
		fatal(S("failed to open X Display\n"));
	}
	x11.root = DefaultRootWindow(x11.dpy);

	for (int i = 1; i < argc; ++i) {
		Str arg = str_from_cstr(argv[i]);
		if (str_eq(arg, S("--geom")) || str_eq(arg, S("-g"))) {
			if (!parse_geom(opt.v, str_from_cstr(argv[++i]))) {
				fatal(S("invalid geometry\n"));
			}
		} else if (str_eq(arg, S("--cursor")) || str_eq(arg, S("-c"))) {
			opt.capture_cursor = true;
		} else if (str_eq(arg, S("--help")) || str_eq(arg, S("-h"))) {
			fatal(usage);
		} else if (str_eq(arg, S("--version")) || str_eq(arg, S("-v"))) {
			fatal(version);
		} else {
			fatal(S("unknown argument: `"), arg, S("`\n"));
		}
	}

	if (isatty(1)) {
		fatal(S("aborting: stdout is connected to a terminal\n"));
	}

	if (opt.x < 0) {
		XWindowAttributes tmp;
		if (XGetWindowAttributes(x11.dpy, x11.root, &tmp) == 0) {
			fatal(S("XGetWindowAttributes failed\n"));
		}
		opt.x = tmp.x;
		opt.y = tmp.y;
		opt.h = tmp.height;
		opt.w = tmp.width;
	}

	XImage *im = XGetImage(
		x11.dpy, x11.root, opt.x, opt.y, opt.w, opt.h,
		AllPlanes, ZPixmap
	);
	if (im == NULL) {
		fatal(S("XGetImage failed\n"));
	}
	if (im->bits_per_pixel != 32 || im->bytes_per_line != (im->width * 4) ||
	    !(im->depth == 24 || im->depth == 32))
	{
		fatal(S("unsupported XImage format\n"));
	}

	if (opt.capture_cursor) {
		if (XFixesQueryVersion(x11.dpy, (int []){0}, (int []){0}) != True) {
			fatal(S("XFixesQueryVersion failed\n"));
		}
		XFixesCursorImage *cur = XFixesGetCursorImage(x11.dpy);
		if (cur == NULL) {
			fatal(S("XFixesGetCursorImage failed\n"));
		}
		blend_cursor(im, cur);
#ifdef DEBUG
		XFree(cur);
#endif
	}

	write_ppm((u8 *)im->data, im->width, im->height, im->byte_order == MSBFirst);

#ifdef DEBUG
	XDestroyImage(im);
#endif
	XCloseDisplay(x11.dpy);

	return 0;
}

// TODO: multimonitor support
// TODO?: add a --file-output flag
// TODO?: add farbfeld support
// TODO?: support for more XImage formats

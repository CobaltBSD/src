# sxot - Simple X screenshOT

`sxot` is an extremely simple screenshotting tool for X11 designed with the unix
philosophy in mind. This means that *by itself* `sxot` doesn't do much - it
simply takes a screenshot and outputs a binary [ppm][] file to stdout. `sxot` is
meant to be used in conjunction with other tools in order to be useful in
practice.

[ppm]: https://en.wikipedia.org/wiki/Netpbm#PPM_example

## Usage

`sxot` supports only two options:

* `-c, --cursor` adds the cursor to the screenshot.
* `-g, --geom <x,y,w,h>` which tells `sxot` to capture the specified rectangle
  instead of screenshotting the entire screen.

Some example usage:

* Taking a full screen screenshot and saving it to `out.ppm`:

```console
$ sxot > out.ppm
```

* Screenshoting a selected area with [`sx4`][sx4]:

```console
$ sxot -g $(sx4) > out.ppm
```

* Screenshoting with a 5 seconds delay with [`sleep`][sleep]
  and saving it with a file-name that has data and time information
  with [`date`][date]:

```console
$ sleep 5 && sxot > $(date '+%F_%T').ppm
```

* Screenshoting with a 2 seconds delay after selection with [`slop`][slop]:

```console
$ sxot --geom $(slop -f "%x,%y,%w,%h"; sleep 2;) > out.ppm
```

* Saving a png screenshot using [`ffmpeg`][ffmpeg]:

```console
$ sxot | ffmpeg -i - out.png
```

* Copying an optimized png screenshot to clipboard,
  using [`optipng-pipe`][op-pipe] and [`xclip`][xclip]:

```console
$ sxot | optipng-pipe | xclip -selection clipboard -target image/png
```

[sx4]: https://codeberg.org/NRK/sx4
[slop]: https://github.com/naelstrof/slop
[xclip]: https://github.com/astrand/xclip
[sleep]: https://pubs.opengroup.org/onlinepubs/9699919799/utilities/sleep.html
[date]: https://pubs.opengroup.org/onlinepubs/9699919799/utilities/date.html
[ffmpeg]: https://ffmpeg.org

## Output formats

`sxot` only supports ppm format. Instead of trying to support complicated
compressed formats and doing a mediocre job, `sxot` leaves this task to more
specialized tools such as [`optipng`][optipng].

Some recommended formats and tools:

* I suggest using png with [`optipng-pipe`][op-pipe] for best compatibility and
  reasonably low file-sizes:

```console
$ sxot | optipng-pipe > out.png
```

* If smaller file-sizes are desired, then I can suggest using lossless webp with
  [`cwebp`][cwebp]. Keep in mind that some compatibility is lost since older
  software might not support webp:

```console
$ sxot | cwebp -quiet -lossless -z 8 -mt -o out.webp -- -
```

The `cwebp` tool comes with `libwebp`, however your distro might package it
separately. Conveniently `cwebp` accepts stdin if the file is named "-",
although this feature is undocumented.

- - -

`jxl` also [seems promising][lossless-bench] in terms of lossless compression.
But compatibility isn't that great as of now (party due to
[google killing it][jxl_is_kil] in chromium).

[optipng]: https://optipng.sourceforge.net
[op-pipe]: ./etc/optipng-pipe
[cwebp]: https://developers.google.com/speed/webp/docs/cwebp
[lossless-bench]: https://siipo.la/blog/whats-the-best-lossless-image-format-comparing-png-webp-avif-and-jpeg-xl
[jxl_is_kil]: https://www.fsf.org/blogs/community/googles-decision-to-deprecate-jpeg-xl-emphasizes-the-need-for-browser-choice-and-free-formats

## Dependencies

- Build Dependencies:
  * C11 compiler
  * POSIX 2001 compatible C standard library.
  * Necessary library headers

- Runtime Dependencies:
  * X11 server (with true color enabled)
  * Xlib
  * Xfixes

## Building

* Simple build:

```console
$ cc -o sxot sxot.c -s -l X11 -l Xfixes
```

* Recommended optimized build:

```console
$ gcc -o sxot sxot.c -Ofast -march=native -fwhole-program -fno-plt \
    -fno-semantic-interposition -fgraphite-identity -floop-nest-optimize \
    -fipa-pta -fno-asynchronous-unwind-tables -fno-ident -fno-pie \
    -s -no-pie -l X11 -l Xfixes
```

* Recommended debug build:

```console
$ gcc -o sxot sxot.c -std=c11 -Wall -Wextra -Wpedantic -Wshadow \
    -g3 -D DEBUG -O0 -fsanitize=address,undefined -l X11 -l Xfixes
```

* Optionally run some static analysis:

```console
$ make -f etc/analyze.mk
```

## Caveats

* Multi-monitor support might be broken and/or shabby.

I do not use a multi-monitor setup, so unlikely to be fixed by me. If you care
about multi-monitor support then feel free to open a Pull-Request or send me the
patches via mail.

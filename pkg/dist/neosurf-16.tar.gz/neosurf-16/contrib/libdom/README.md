# LibDOM

LibDOM is an implementation of the W3C DOM API in C.

## API documentation
Currently, there is none. However, the code is well commented and the public API may be found in the "include" directory.

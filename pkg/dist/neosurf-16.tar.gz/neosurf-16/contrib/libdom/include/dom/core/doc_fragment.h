/*
 * This file is part of libdom.
 * Licensed under the MIT License,
 *                http://www.opensource.org/licenses/mit-license.php
 */

#ifndef dom_core_documentfragment_h_
#define dom_core_documentfragment_h_

typedef struct dom_document_fragment dom_document_fragment;

#endif

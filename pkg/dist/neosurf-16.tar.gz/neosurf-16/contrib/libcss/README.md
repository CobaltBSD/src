# LibCSS

LibCSS is a CSS parser and selection engine. It aims to parse the forward compatible CSS grammar.

## API documentation
Currently, there is none. However, the code is well commented and the public API may be found in the "include" directory.

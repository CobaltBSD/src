#!/usr/bin/env python3

import sys

if len(sys.argv) > 1:
    print(sys.argv[1])

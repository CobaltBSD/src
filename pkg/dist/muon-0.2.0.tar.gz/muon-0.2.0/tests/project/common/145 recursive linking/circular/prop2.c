int get_st2_prop (void) {
  return 2;
}

#include<assert.h>
char func_b(void);
char func_c(void);

int main(void) {
    if(func_b() != 'b') {
        return 1;
    }
    if(func_c() != 'c') {
        return 2;
    }
    return 0;
}

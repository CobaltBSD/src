#include <stdio.h>

int bar_dummy_func(void);
int dummy_func(void);

int main(void) {
    printf("Hello world %d\n", bar_dummy_func() + dummy_func());
    return 0;
}

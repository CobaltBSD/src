int subfunc(void) {
    return 42;
}

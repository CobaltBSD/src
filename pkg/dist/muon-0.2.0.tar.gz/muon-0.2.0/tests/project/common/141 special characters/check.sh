#!/bin/sh
set -eux
test -f "$DESTDIR"/usr/share/result
test -f "$DESTDIR"/usr/share/result2

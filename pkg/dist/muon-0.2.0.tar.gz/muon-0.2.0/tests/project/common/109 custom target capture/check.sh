#!/bin/sh
set -eux
test -f "$DESTDIR"/usr/subdir/data.dat

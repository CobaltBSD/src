/*
 * SPDX-FileCopyrightText: Stone Tickle <lattis@mochiro.moe>
 * SPDX-License-Identifier: GPL-3.0-only
 */

#ifndef MUON_FUNCTIONS_DICT_H
#define MUON_FUNCTIONS_DICT_H
#include "functions/common.h"

extern const struct func_impl_name impl_tbl_dict[];
#endif

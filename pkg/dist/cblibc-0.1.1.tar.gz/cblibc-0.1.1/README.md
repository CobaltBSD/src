# cblibc

The Cobalt C library. At the moment it is essentially identical to the OpenBSD libc as of 7.4, but is separated into its own package.

## Compilation

At the moment, cblibc must be built with Clang and BSD make. Support for tinycc is planned.

## Portability

cblibc is not portable to Linux or necessarily other BSDs.

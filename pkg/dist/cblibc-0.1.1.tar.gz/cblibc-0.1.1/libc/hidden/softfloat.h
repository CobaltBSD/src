/*	$OpenBSD: softfloat.h,v 1.1 2015/09/13 14:23:43 miod Exp $	*/
/* public domain */

#ifndef _LIBC_SOFTFLOAT_H_
#define	_LIBC_SOFTFLOAT_H_

#include_next <softfloat.h>

PROTO_NORMAL(float_raise);

#endif

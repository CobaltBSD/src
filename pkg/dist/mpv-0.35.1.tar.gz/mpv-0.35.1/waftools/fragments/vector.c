int main(int argc, char **argv) {
    float v __attribute__((vector_size(32)));
    return 0;
}
